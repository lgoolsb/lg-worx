const p=document.getElementById('panel');
document.querySelectorAll('.tile').forEach(t=>t.onclick=()=>{
 if(t.dataset.tool==='Sine Block'){
  p.innerHTML='<h2>📐 Sine Block Calculator (Preview)</h2><p>This calculator will be fully functional in v0.2.</p><label>Angle</label><input value="18.5°"><label>Sine Bar</label><select><option>6 in</option></select><p><b>Gauge Block Stack:</b> 1.9058 in</p>';
 } else {
  p.innerHTML='<h2>'+t.dataset.tool+'</h2><p>Coming soon.</p>';
 }
});
inBtn.onclick=()=>{inBtn.classList.add('active');mmBtn.classList.remove('active');}
mmBtn.onclick=()=>{mmBtn.classList.add('active');inBtn.classList.remove('active');}
